<?php
//error_reporting(0);
if(isset($_POST)){
$name=trim($_POST['name']);
$email=trim($_POST['email']);
$password1=trim($_POST['password']);
$conpassword1=trim($_POST['confirmPassword']);
$uname=trim($_POST['userName']);
$utype=$_POST['radio'];
$dob=$_POST['dob'];
if(isset($_POST['radio'])) {
    if($_POST['radio'] == 'male') {
		$utype='male';
       
    } elseif($_POST['radio'] == 'female') {
		$utype='female';
        
    }
	elseif($_POST['radio'] == 'other') {
		$utype='other';
       
    }
}


  if($password1!=$conpassword1){
      echo"password dont match";
  }
  else{

	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="webtec";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "insert into user values('$name','$email','$uname','$password1','$utype','$dob')";
	
	if(mysqli_query($conn, $sql)){
		echo "<br/> Data Inserted!";
	}else{
		echo "<br/> SQL Error".mysqli_error($conn);
	}

	mysqli_close($conn);
	header('location:login.html');
  
	/*$myfile= fopen("regdata.txt", "a+") or die("Unable to open file!");
	
    //echo"registration completed";

	fwrite($myfile,$data);
	fclose($myfile);
	header('location:login.html');
	
	
	*/

  }



}


?>