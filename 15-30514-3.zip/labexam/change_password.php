<?php
if(isset($_POST)){
		session_start();
		if(isset($_SESSION["name"]){

		$sname=$_SESSION["name"];
		$stype=$_SESSION["type"];
		$currentpassword=$_POST["currentpassword"];
		$npassword=$_POST["password"];
		$conpassword=$_POST["conpassword"];



			if($password==$conpassword){
				if(isset($_POST){
				$servername ="localhost";
					$username 	="root";
					$password 	="";
					$dbname 	="webtec";
					
					$conn = mysqli_connect($servername, $username, $password, $dbname);
					
					if(!$conn){
						die("Connection Error!".mysqli_connect_error());
					}
					
					$sql = "select * from user where name='$sname' and password='$currentpassword'";
					$result = mysqli_query($conn, $sql);
					
					if(mysqli_num_rows($result)>0){
					
						 //$row=mysqli_fetch_assoc($result);
						 $sql ="UPDATE user SET password='$npassword' WHERE name='$sname' and password='$currentpassword'";

						  $result = mysqli_query($conn, $sql);
						  mysqli_close($conn);
						 
						
						//while($row=mysqli_fetch_assoc($result)){
							//echo "ID: ".$row['id']."<br/>NAME: ".$row['name']."<br/>PASSWORD: ".$row['password']."<br/><br/>";
						
						
					}else{
						echo "Result not found!";
					}

					
				}
				}
				


			}
}


?>
<center>

	<form method="POST" action="#">
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset>
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<input type="password" /><br />
						New Password<br />
						<input type="password" /><br />
						Retype New Password<br />
						<input type="password"/>								
						<hr />
						<input type="submit" value="Change" />     
						<a href="home.html">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>