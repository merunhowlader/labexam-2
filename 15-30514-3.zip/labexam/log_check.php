<?php
if(isset($_POST)){
$password1=trim($_POST['password']);
$id1=trim($_POST['id']);

$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="webtec";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from user where id='$id1' AND password='$password1'";
	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result)>0){
		//header('location:user_home.html');
		$row=mysqli_fetch_assoc($result);
		 session_start();
		 $_SESSION["name"] = $row['name'];
		 $_SESSION["type"] = $row['utype'];
		
		
		
          
		   
		   if($row['utype']=='User'){
			   
			   header('location:user_home.html');
		   }
		   elseif($row['utype']=='Admin'){
			   
			    header('location:admin_home.html');
		   }
		//if()
		//header('location:admin_home.html');
		/*while($row=mysqli_fetch_assoc($result)){
			echo "ID: ".$row['id']."<br/>NAME: ".$row['name']."<br/>PASSWORD: ".$row['password']."<br/><br/>";
			
		}*/
		
		
	}else{
		echo "Result not found!";
		
		header('location:login.html');
	}

	mysqli_close($conn);





/*header('location:profile.html');


$f=fopen("regdata.txt","r");
$file=fgets($f);
 $array = explode(':',$file);



print_r(explode(':',$file));

fclose($f);


while(arry[1]==$id1){
	
	$array = explode(':',$file);
	
	while(arry[1]==$password1){
		
		header('location:profile.html');
	
		
	}*/
	
	
}





?>